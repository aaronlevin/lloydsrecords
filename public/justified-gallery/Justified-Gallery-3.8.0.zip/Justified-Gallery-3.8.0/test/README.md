This folder contains tests to ensure that JG works properly.

Making automatic tests to check that things are visually appealing is difficult. 
For now these tests only show specific configurations and can be check by an human.

To visualize them execute in the root folder:

  http-serve

and open the single pages. For example:

  http://localhost:8000/test/main/basic_test.html
